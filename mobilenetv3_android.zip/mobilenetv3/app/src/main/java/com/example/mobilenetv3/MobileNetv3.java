package com.example.mobilenetv3;

import android.graphics.Bitmap;


public class MobileNetv3 {
    public native boolean Init(byte[] param, byte[] bin, byte[] words);

    public native String Detect(Bitmap bitmap, boolean use_gpu);

    static {
        System.loadLibrary("MobileNetv3");
    }
}
